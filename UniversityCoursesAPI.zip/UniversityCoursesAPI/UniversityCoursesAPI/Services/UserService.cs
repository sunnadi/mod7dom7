﻿using UniversityCoursesAPI.Models;

namespace UniversityCoursesAPI.Services
{
    public interface IUserService
    {
        User? ValidateUser(string login, string password);
    }

    public class UserService : IUserService
    {
        private readonly List<User> _users = new()
        {
            new User { Id = 1, Login = "admin",   Password = "admin123",   Email = "admin@university.test",   Role = "Admin" },
            new User { Id = 2, Login = "teacher", Password = "teacher123", Email = "teacher@university.test", Role = "Teacher" },
            new User { Id = 3, Login = "student", Password = "student123", Email = "student@university.test", Role = "Student" }
        };

        public User? ValidateUser(string login, string password)
        {
            return _users.FirstOrDefault(u => u.Login == login && u.Password == password);
        }
    }
}