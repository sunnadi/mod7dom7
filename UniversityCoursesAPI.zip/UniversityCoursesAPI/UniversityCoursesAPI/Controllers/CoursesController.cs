﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCoursesAPI.Attributes;
using UniversityCoursesAPI.Models;

namespace UniversityCoursesAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [BasicAuthentication]
    public class CoursesController : ControllerBase
    {
        private static readonly List<Course> courses = new()
        {
            new Course { Id = 1, Title = "Web Services",        Description = "Разработка REST API на ASP.NET Core", Teacher = "Герцен Е.А.",    Duration = 48 },
            new Course { Id = 2, Title = "Databases",           Description = "Реляционные базы данных и SQL",      Teacher = "Сериков М.К.",   Duration = 36 },
            new Course { Id = 3, Title = "Algorithms",          Description = "Алгоритмы и структуры данных",       Teacher = "Нурланов А.Б.",  Duration = 60 },
            new Course { Id = 4, Title = "Information Security",Description = "Основы информационной безопасности",  Teacher = "Ахметова Д.Р.",  Duration = 42 },
            new Course { Id = 5, Title = "Machine Learning",    Description = "Введение в машинное обучение",       Teacher = "Ким С.В.",       Duration = 54 }
        };

        [MyAuthorize("Admin", "Teacher", "Student")]
        [HttpGet]
        public ActionResult<List<Course>> GetAll()
        {
            return Ok(courses);
        }

        [MyAuthorize("Admin", "Teacher", "Student")]
        [HttpGet("{id:int}")]
        public ActionResult<Course> GetById(int id)
        {
            var course = courses.FirstOrDefault(c => c.Id == id);
            if (course == null) return NotFound();
            return Ok(course);
        }

        [MyAuthorize("Admin", "Teacher")]
        [HttpPost]
        public ActionResult<Course> Create(Course newCourse)
        {
            newCourse.Id = courses.Any() ? courses.Max(c => c.Id) + 1 : 1;
            courses.Add(newCourse);
            return CreatedAtAction(nameof(GetById), new { id = newCourse.Id }, newCourse);
        }

        [MyAuthorize("Admin", "Teacher")]
        [HttpPut("{id:int}")]
        public IActionResult Update(int id, Course updated)
        {
            var course = courses.FirstOrDefault(c => c.Id == id);
            if (course == null) return NotFound();

            course.Title = updated.Title;
            course.Description = updated.Description;
            course.Teacher = updated.Teacher;
            course.Duration = updated.Duration;

            return Ok(course);
        }

        [MyAuthorize("Admin")]
        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            var course = courses.FirstOrDefault(c => c.Id == id);
            if (course == null) return NotFound();

            courses.Remove(course);
            return Ok(new { message = $"Курс {id} удалён" });
        }

        [AllowAnonymous]
        [HttpGet("info")]
        public IActionResult GetInfo()
        {
            return Ok(new
            {
                name = "UniversityCoursesAPI",
                description = "API системы управления учебными курсами университета",
                totalCourses = courses.Count
            });
        }
    }
}