﻿using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using UniversityCoursesAPI.Services;

namespace UniversityCoursesAPI.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class BasicAuthenticationAttribute : Attribute, IAuthorizationFilter, IOrderedFilter
    {
        public int Order => 1;

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (context.ActionDescriptor.EndpointMetadata.OfType<IAllowAnonymous>().Any())
            {
                return;
            }

            var authHeader = context.HttpContext.Request.Headers["Authorization"].ToString();

            if (string.IsNullOrWhiteSpace(authHeader) ||
                !authHeader.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
            {
                Reject(context, "Требуется аутентификация (заголовок Authorization: Basic ...)");
                return;
            }

            string decoded;
            try
            {
                var encoded = authHeader.Substring("Basic ".Length).Trim();
                decoded = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
            }
            catch (FormatException)
            {
                Reject(context, "Некорректный формат учётных данных");
                return;
            }

            var separatorIndex = decoded.IndexOf(':');
            if (separatorIndex < 0)
            {
                Reject(context, "Некорректный формат учётных данных");
                return;
            }

            var login = decoded.Substring(0, separatorIndex);
            var password = decoded.Substring(separatorIndex + 1);

            var userService = context.HttpContext.RequestServices.GetRequiredService<IUserService>();
            var user = userService.ValidateUser(login, password);

            if (user == null)
            {
                Reject(context, "Неверный логин или пароль");
                return;
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Login),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var identity = new ClaimsIdentity(claims, "Basic");
            var principal = new ClaimsPrincipal(identity);

            context.HttpContext.User = principal;
        }

        private static void Reject(AuthorizationFilterContext context, string message)
        {
            context.HttpContext.Response.Headers["WWW-Authenticate"] = "Basic realm=\"UniversityCoursesAPI\"";
            context.Result = new UnauthorizedObjectResult(new { message });
        }
    }
}